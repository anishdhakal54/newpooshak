<?php
$email=':email';

return [

    /*
    |--------------------------------------------------------------------------
    | Admin Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'name' => "Pooshak",
    'address' => "Gyaneshwor Marg,Kathmandu,Nepal",
    'money_symbol' => "NRs.",
    'email' => "info@pooshak.com",
    'latitude' => "27.7055822",
    'logitude' => "85.330885",
    'url' =>'http://pooshak.local/',



];
