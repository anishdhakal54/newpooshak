


<h2> The Product in the Enquiry has been Updated,Please check the following link for details</h2>


Thanks,<br>
{{ config('app.name') }}


