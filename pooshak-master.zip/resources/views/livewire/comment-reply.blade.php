@if(!empty($comments['replies']))
    <div class="single-review child-review">
        <div class="review-img">
            <img src="assets/images/testimonial-image/2.png" alt=""/>
        </div>
        <div class="review-content">
            <div class="review-top-wrap">
                <div class="review-left">
                    <div class="review-name">
                        <h4>White Lewis</h4>
                        <span class="date">February 16, 2020 at 1:38 am</span>
                    </div>
                </div>
                <div class="review-left">
                    <a href="#">Reply</a>
                </div>
            </div>
            <div class="review-bottom">
                <p>Vestibulum ante ipsum primis aucibus orci luctustrices posuere cubilia Curae Sus pen disse viverra ed
                    viverra. Mauris ullarper euismod vehicula.</p>
            </div>
        </div>
    </div>
@endif
