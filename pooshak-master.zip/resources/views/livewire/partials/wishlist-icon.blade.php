<span style="color: red;
    position: absolute;
    top: 10px;
    font-size: 23px;
    left: 35px;" wire:click="add_to_wishlist">
<i wire:loading wire:target="add_to_wishlist" class="fa fa-spinner fa-spin"></i> <i class="fa fa-heart"></i>
</span>

