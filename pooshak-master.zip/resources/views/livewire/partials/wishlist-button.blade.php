  <button type="button" wire:click="add_to_wishlist" wire:loading.class="disabled">
    <i wire:loading wire:target="add_to_wishlist" class="fa fa-spinner fa-spin"></i> <i class="icon-heart"></i>
    Wishlist

  </button>