<div>

  {{--  <div class="shop-area pt-20 pb-20 newhos">
      <div class="container-fluid">
        <div class="row flex-row-reverse">
          <div class="col-lg-9">
            <img src="../assets/images/atm-banner.png">
            <div class="shop-topbar-wrapper">
              <div class="shop-topbar-left">
                <p> 7 results found!!!</p>
              </div>
              <div class="product-sorting-wrapper">

                <div class="product-show shorting-style">
                  <label>Sort by :</label>
                  <select wire:model="orderby" wire:change="filter" wire:loading.class="disabled">
                    <option value="1" selected="selected">Default sorting</option>
                    <option value="2">Sort by popularity</option>
                    <option value="3">Sort by newness</option>
                    <option value="4">Sort by price: low to high</option>
                    <option value="5">Sort by price: high to low</option>
                  </select>
                  <i wire:loading="" wire:target="filter" class="fas fa-spinner fa-spin"></i>

                </div>
              </div>
            </div>
            <div class="shop-bottom-area">
              <div class="tab-content jump">
                <div id="shop-1" class="tab-pane active">
                  <div class="row">
                    <div wire:id="zUiQ1TjK5MFulLnErRxU" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/ursa-rush" data-images="http://poshaak.nextaussietech.com/uploads/product/images/6/v/g/medium-b-large-1.jpg|http://poshaak.nextaussietech.com/uploads/product/images/n/t/a/medium-product-6.jpg" class="album">

                            <img src="../uploads/product/images/6/v/g/medium-b-large-1.jpg" alt="Ursa Rush" style="opacity: 0;">

                            <img src="http://poshaak.nextaussietech.com/uploads/product/images/6/v/g/medium-b-large-1.jpg" style="opacity: 1;"><img src="http://poshaak.nextaussietech.com/uploads/product/images/n/t/a/medium-product-6.jpg"></a>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/ursa-rush">Ursa Rush</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 980.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/ursa-rush">Ursa Rush</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 980.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/ursa-rush">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="rFIGi6q1EYqZ6KMUHefH" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/tarik-ferrell" data-images="http://poshaak.nextaussietech.com/uploads/product/images/z/g/p/medium-banner-3.jpg" class="album">

                            <img src="../uploads/product/images/z/g/p/medium-banner-3.jpg" alt="Tarik Ferrell">

                          </a>
                          <span class="pro-badge left bg-red">Save 42%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/tarik-ferrell">Tarik Ferrell</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 523.00</span>
                              <span class="old-price">NRs. 905.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/tarik-ferrell">Tarik Ferrell</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 523.00</span>
                              <span class="old-price">NRs. 905.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/tarik-ferrell">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="kss8QOs2IGkCoO2y03Ks" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/lila-baldwin" data-images="http://poshaak.nextaussietech.com/uploads/product/images/o/y/d/medium-FA-03-WB.JPG" class="album">

                            <img src="../uploads/product/images/o/y/d/medium-FA-03-WB.jpg" alt="Lila Baldwin">

                          </a>
                          <span class="pro-badge left bg-red">Save 12%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/lila-baldwin">Lila Baldwin</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 595.00</span>
                              <span class="old-price">NRs. 673.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/lila-baldwin">Lila Baldwin</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 595.00</span>
                              <span class="old-price">NRs. 673.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/lila-baldwin">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="H9ARUjsroMm2QpxiC5eB" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/nell-david" data-images="http://poshaak.nextaussietech.com/uploads/product/images/a/5/o/medium-a11.jpg|http://poshaak.nextaussietech.com/uploads/product/images/r/c/k/medium-a12.jpg" class="album">

                            <img src="../uploads/product/images/a/5/o/medium-a11.jpg" alt="Nell David">

                          </a>
                          <span class="pro-badge left bg-red">Save 5%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/nell-david">Nell David</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 596.00</span>
                              <span class="old-price">NRs. 625.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/nell-david">Nell David</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 596.00</span>
                              <span class="old-price">NRs. 625.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/nell-david">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="lth21IA7oRiqf23GgBkQ" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/paloma-maddox" data-images="http://poshaak.nextaussietech.com/uploads/product/images/b/p/3/medium-a1.jpg|http://poshaak.nextaussietech.com/uploads/product/images/v/p/s/medium-a2.jpg" class="album">

                            <img src="../uploads/product/images/b/p/3/medium-a1.jpg" alt="Paloma Maddox">

                          </a>
                          <span class="pro-badge left bg-red">Save 15%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/paloma-maddox">Paloma Maddox</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 542.00</span>
                              <span class="old-price">NRs. 641.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/paloma-maddox">Paloma Maddox</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 542.00</span>
                              <span class="old-price">NRs. 641.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/paloma-maddox">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="arFq7oCiJhoTGpLV8OIi" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/rhea-powers" data-images="http://poshaak.nextaussietech.com/uploads/product/images/k/l/g/medium-a5.jpg|http://poshaak.nextaussietech.com/uploads/product/images/v/l/k/medium-a9.jpg" class="album">

                            <img src="../uploads/product/images/k/l/g/medium-a5.jpg" alt="Rhea Powers">

                          </a>
                          <span class="pro-badge left bg-red">Save 35%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/rhea-powers">Rhea Powers</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 285.00</span>
                              <span class="old-price">NRs. 441.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/rhea-powers">Rhea Powers</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 285.00</span>
                              <span class="old-price">NRs. 441.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/rhea-powers">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div wire:id="BXqd8gIXT96al8LzkyUy" class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                      <div class="single-product-wrap mb-35">
                        <div class="product-img product-img-zoom mb-15 albmum-preview">
                          <a href="http://poshaak.nextaussietech.com/product/lila-roach" data-images="http://poshaak.nextaussietech.com/uploads/product/images/g/z/6/medium-a8.jpg|http://poshaak.nextaussietech.com/uploads/product/images/s/j/y/medium-a7.jpg" class="album">

                            <img src="../uploads/product/images/g/z/6/medium-a8.jpg" alt="Lila Roach">

                          </a>
                          <span class="pro-badge left bg-red">Save 28%</span>


                        </div>
                        <div class="product-content-wrap-2 text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/lila-roach">Lila Roach</a>
                          </h3>
                          <div class="product-price-2">

                            <div class="product-price text-center">
                              <span class="new-price">NRs. 431.00</span>
                              <span class="old-price">NRs. 597.00</span>
                            </div>
                          </div>
                        </div>
                        <div class="product-content-wrap-2 product-content-position text-center">

                          <h3>
                            <a href="http://poshaak.nextaussietech.com/product/lila-roach">Lila Roach</a>
                          </h3>
                          <div class="product-price-2">
                            <div class="product-price text-center">
                              <span class="new-price">NRs. 431.00</span>
                              <span class="old-price">NRs. 597.00</span>
                            </div>
                          </div>
                          <div class="pro-add-to-cart">
                            <a href="http://poshaak.nextaussietech.com/product/lila-roach">
                              <button title="Add to Cart">Customize</button>
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
              <div class="pro-pagination-style text-center mt-10">

              </div>
            </div>
          </div>
          <div class="col-lg-3">
            <div class="sidebar-wrapper sidebar-wrapper-mrg-right">


              <div class="sidebar-widget shop-sidebar-border mb-40 pt-40" wire:ignore="">
                <h4 class="sidebar-widget-title">Price Filter</h4>


                <div class="price-filter">
                  <div id="slider-range" class="ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"><div class="ui-slider-range ui-corner-all ui-widget-header" style="left: 0%; width: 20.5202%;"></div><span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default" style="left: 0%;"></span><span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default" style="left: 20.5202%;"></span></div>
                  <div class="price-slider-amount">
                    <div class="label-input">
                      <input type="text" id="amount" name="price" placeholder="Add Your Price">
                    </div>
                  </div>

                  <div class="price-slider-amount">
                    <div class="label-input">
                      <div class="">
                        <input type="hidden" id="min_price" class="form-control" name="price" wire:model="min" placeholder="Min" value="0">
                        <input type="hidden" id="max_price" class="form-control" name="price" wire:model="max" placeholder="Max" value="10000">

                      </div>


                    </div>
                    <br>
                    <button type="button" wire:click="filterbyPrice" wire:loading.class="disabled">
                      <span style="margin-bottom:0"><i wire:loading="" wire:target="filterbyPrice" class="fas fa-spinner fa-spin"></i> Filter</span>
                    </button>
                  </div>
                </div>
              </div>

              <div class="sidebar-widget shop-sidebar-border mb-35 pt-40">
                <h4 class="sidebar-widget-title">All Categories</h4>
                <div class="shop-catigory">
                  <ul>

                    <li><a href="hotel-uniform.html">Hotel Uniform</a></li>


                    <li><a href="tshirt.html">Tshirt</a></li>


                    <li><a href="hospital-uniform.html">Hospital Uniform</a></li>


                    <li><a href="apron.html">Apron</a></li>


                    <li><a href="housekeeping-uniform.html">Housekeeping Uniform</a></li>


                    <li><a href="industrial-uniform.html">Industrial Uniform</a></li>


                    <li><a href="other-products-1.html">Other Products</a></li>


                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>--}}


  <div class="shop-area pt-20 pb-20">
    <div class="container-fluid">
      <div class="row flex-row-reverse">
        <div class="col-lg-9" style="padding-left: 0">
          @livewire('partials.slideshows')

          <div class="shop-topbar-wrapper">
            <div class="shop-topbar-left">
              <p> {{$products->total()}} results found!!!</p>
            </div>
            <div class="product-sorting-wrapper">

              <div class="product-show shorting-style">
                <label>Sort by :</label>
                <select wire:model="orderby" wire:change="filter" wire:loading.class="disabled">
                  <option value="1" selected="selected">Default sorting</option>
                  <option value="2">Sort by popularity</option>
                  <option value="3">Sort by newness</option>
                  <option value="4">Sort by price: low to high</option>
                  <option value="5">Sort by price: high to low</option>
                </select>
                <i wire:loading wire:target="filter" class="fas fa-spinner fa-spin"></i>

              </div>
            </div>
          </div>
          <div class="shop-bottom-area">
            <div class="tab-content jump">
              <div id="shop-1" class="tab-pane active">
                <div class="row">
                  @if(count($products) <= 0)
                    <div class="alert alert-danger">
                      No products found.
                    </div>
                  @else
                    @foreach($products as $product)
                      @livewire('partials.product-shop-item',['product' => $product],key($product->id))
                    @endforeach
                  @endif
                </div>
              </div>

            </div>
            <div class="pro-pagination-style text-center mt-10">
              {{ $products->links() }}
            </div>
          </div>
        </div>
        <div class="col-lg-3">
          <div class="sidebar-wrapper sidebar-wrapper-mrg-right">

            @if($productSubCategories->count()>0)
              <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                  <div class="panel-heading" role="tab" id="headingOne">
                    <h4 class="panel-title">
                      <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne"
                         aria-expanded="true" aria-controls="collapseOne">
                        {{$category->name}}
                      </a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in show" role="tabpanel"
                       aria-labelledby="headingOne">
                    <div class="panel-body">
                      <div class="shop-catigory">
                        <ul>
                          @foreach($productSubCategories as $key=>$productCategory)
                            <li><a href="/category/{{$productCategory['slug']}}">{{ $productCategory['name']}}</a></li>
                          @endforeach

                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            @endif

            <div class="sidebar-widget shop-sidebar-border mb-40 pt-40" wire:ignore>
              <h4 class="sidebar-widget-title">Price Filter</h4>


              <div class="price-filter">
                <div id="slider-range"></div>
                <div class="price-slider-amount">
                  <div class="label-input">
                    <input
                        type="text"
                        id="amount"
                        name="price"
                        placeholder="Add Your Price"
                    />
                  </div>
                </div>

                <div class="price-slider-amount">
                  <div class="label-input">
                    <div class="">
                      <input type="hidden" id="min_price" class="form-control" name="price" wire:model="min"
                             placeholder="Min"/>
                      <input type="hidden" id="max_price" class="form-control" name="price" wire:model="max"
                             placeholder="Max"/>

                    </div>


                  </div>
                  
                </div>
              </div>
            </div>

{{--            <div class="sidebar-widget shop-sidebar-border mb-35 pt-40">--}}
{{--              <h4 class="sidebar-widget-title">All Categories</h4>--}}
{{--              <div class="shop-catigory">--}}
{{--                <ul>--}}
{{--                  @foreach($productCategories as $key=>$productCategory)--}}

{{--                    <li><a href="/category/{{$productCategory['slug']}}">{!!   $productCategory['name']!!}</a></li>--}}

{{--                  @endforeach--}}

{{--                </ul>--}}
{{--              </div>--}}
{{--            </div>--}}
<div>

              <a href="{{getConfiguration('ad4_link')}}">
                <img class="full-width" alt="advertisement" src="{{ url('storage') . '/' . getConfiguration('ad4') }}"/>
              </a>
</div>
            <div>
              <a href="{{getConfiguration('ad5_link')}}">
                <img class="full-width" alt="advertisement" src="{{ url('storage') . '/' . getConfiguration('ad5') }}"/>
              </a>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
  @push('styles')
    <meta name="turbolinks-visit-control" content="reload"/>
    <style>
      #accordion .panel {
        border: none;
        box-shadow: none;
        border-radius: 0;
        margin-bottom: 15px;
      }

      #accordion .panel-heading {
        padding: 0;
      }

      #accordion .panel-title a {
        display: block;
        font-size: 16px;
        font-weight: bold;
        line-height: 24px;
        color: #000;
        padding: 15px 20px 15px 47px;
        position: relative;
        transition: all 0.5s ease 0s;
      }

      #accordion .panel-title a.collapsed {
        background: #fff;
        border-color: #ddd;
        color: #888;
      }

      #accordion .panel-title a:before {
        content: "\f106";
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        font-size: 18px;
        position: absolute;
        top: 44%;
        left: 20px;
        transition: all 0.3s ease 0s;
      }

      #accordion .panel-title a.collapsed:before {
        content: "\f107";
      }

      #accordion .panel-body {
        font-size: 16px;
        color: #888;
        line-height: 25px;
        border-top: none;
        padding: 14px 20px;
        padding-left: 47px;
        padding-top: 0;
      }

      #accordion .panel-title a {
        border: unset;
        background: unset;
        color: #000;
      }
      .single-product-wrap {
        width: 261px !important;
      }
    </style>
  @endpush
  @push('scripts')
    <script>
      /*---------------------
          Price range
      --------------------- */
      var sliderrange = $("#slider-range");
      var amountprice = $("#amount");
      $(function () {
        sliderrange.slider({
          range: true,
          min: 16,
          max: 1400,
          values: [0, 300],
          slide: function (event, ui) {
            amountprice.val("NRs." + ui.values[0] + " - NRs." + ui.values[1]);

            $('#min_price').val(ui.values[0]);
            $('#max_price').val(ui.values[1]);
          @this.set('min', ui.values[0]);
          @this.set('max', ui.values[1]);
          },
        });
        amountprice.val(
          "NRs." +
          sliderrange.slider("values", 0) +
          " - NRs." +
          sliderrange.slider("values", 1)
        );
      });
    </script>

  @endpush
</div>

