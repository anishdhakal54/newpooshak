@extends('layouts.app')

@section('content')
<div class="container" style="margin-top: 30px">
        <div class="row">
            <div class="col-md8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Registration </div>
                <div class="panel-body" style="color: #333">
                  Your Account is Pending for Approval!!
                    <br>
                    Sorry For Inconvenience
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection