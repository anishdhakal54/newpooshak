<link rel="stylesheet" href="{{ asset('vendor/sweetalert2/sweetalert2.min.css') }}">
@if(getConfiguration('site_favicon'))
  <link rel="shortcut icon" href="{{ url('storage') . '/' . getConfiguration('site_favicon') }}"
        type="image/x-icon"/>
@endif
<link
    rel="stylesheet"
    href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
/>
<link rel="stylesheet" href="{{asset('notify/css/fonts/vicons.css')}}">
<link rel="stylesheet" href="{{asset('notify/css/fonts/feather.css')}}">
<link rel="stylesheet" href="{{asset('notify/css/fonts/steadysets.css')}}">
<link rel="stylesheet" href="{{asset('notify/css/fonts/linecons.css')}}">
<link rel="stylesheet" href="{{asset('notify/css/igrowl.min.css')}}">
<link rel="stylesheet" href="{{asset('assets/css/vendor/vendor.min.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/plugins/plugins.min.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/lunar.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/album.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/style.css')}}" />
<link rel="stylesheet" href="{{asset('assets/css/custom.css')}}" />
{{--<link rel="stylesheet" href="{{asset('assets/lightbox.min.css')}}" />--}}
<!--  <link rel="stylesheet" href="assets/css/style.min.css"> -->
