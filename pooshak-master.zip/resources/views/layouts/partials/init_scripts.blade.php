<script src="{{asset('assets/js/vendor/vendor.min.js')}}"></script>
<script src="{{asset('assets/js/plugins/plugins.min.js')}}"></script>
<!-- Main JS -->
<script src="{{asset('assets/js/albumpreview.js')}}"></script>
<script src="{{asset('assets/js/jquery.elevateZoom-3.0.8.min.js')}}"></script>
<script src="{{asset('assets/js/main.js')}}"></script>
<script src="{{asset('notify/js/igrowl.min.js')}}"></script>
{{--<script src="{{asset('assets/lightbox-plus-jquery.min.js')}}"></script>--}}
