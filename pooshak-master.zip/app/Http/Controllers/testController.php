<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use App\ProductEnquiry;

class testController extends Controller
{
    public function index(){



    }
}
