<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CommentReply extends Component
{
    public function render()
    {
        return view('livewire.comment-reply');
    }
}
