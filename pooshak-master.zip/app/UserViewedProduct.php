<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserViewedProduct extends Model
{
    //
}
