<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaypalRecord extends Model
{
    //
}
