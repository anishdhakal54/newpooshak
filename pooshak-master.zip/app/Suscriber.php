<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Suscriber extends Model
{
    protected $fillable = ['email','status'];
}
