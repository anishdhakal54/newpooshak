<?php

return [
	/* you can add your own middleware here */
	
	'middleware' => [],

	/* you can set your own table prefix here */
	'table_prefix' => ''
];