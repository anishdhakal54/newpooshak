<?php
return [
  'en' => 'English',
  'ne' => 'Nepali',
];
